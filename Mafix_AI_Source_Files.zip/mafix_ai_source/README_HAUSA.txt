MAFIX AI — SOURCE FILES, FARKON MATAKI

Abubuwan ciki:
- lib/main.dart: babban entry point
- lib/screens/home_screen.dart: shafin farko
- lib/screens/chat_screen.dart: chat preview
- lib/widgets/feature_tile.dart: cards na tools
- assets/icons/mafix_ai_icon.png: icon artwork
- pubspec.yaml: Flutter dependencies

MUHIMMI:
Wannan shi ne UI preview kawai. AI provider bai haɗu ba tukuna, saboda haka chat ba ya ba da
amsoshin AI na gaske tukuna. Image/video generation ma ba su fara aiki ba. Za mu haɗa su a
matakai na gaba. Kada ka saka API key a cikin Flutter source ko GitHub.

Yadda za a haɗa:
1. Ƙirƙiri sabon Flutter project a environment mai Flutter SDK.
2. Maye gurbin lib/ da lib/ ɗin nan.
3. Kwafe assets/ zuwa project.
4. Haɗa pubspec.yaml ɗin nan.
5. Gudanar da flutter pub get, sannan flutter run.
