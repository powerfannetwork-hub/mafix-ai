MAFIX AI - ANDROID FOLDER (WITH INTERNET + MICROPHONE PERMISSIONS)

Wannan ZIP yana dauke da ainihin babban fayil din android/; ba fayil mai suna Android ba.

MUHIMMI: Kada ka goge ko ka maye gurbin sauran project din. Ka fara adana backup.

Yadda za a saka shi:
1. Sauke wannan ZIP sannan ka extract/unzip shi.
2. Za ka ga babban fayil mai suna android.
3. A GitHub repository, ka tabbatar an cire tsohon file mai suna Android (idan har yanzu yana nan kuma ZIP ne).
4. Saka abubuwan da ke cikin android/ a matsayin babban fayil android/ a tushen project, kusa da lib/, pubspec.yaml da assets/.
5. Ka tabbatar hanyar manifest ita ce android/app/src/main/AndroidManifest.xml.
6. Ka yi commit sannan ka gudanar da GitHub Actions.

An saka izinin INTERNET da RECORD_AUDIO a manifest. Amma lambar Flutter dole ta nemi izinin microphone a lokacin da ake amfani da voice; manifest kadai ba ya tabbatar da speech recognition zai yi aiki.

Application ID a cikin wannan Android folder: com.mafixai.app. Idan kana da tsohon application ID daban da aka riga aka wallafa, kada ka canza shi ba tare da dubawa ba.
